#!/bin/bash
sudo yum install tomcat7 tomcat7-webapps -y
