#!/bin/bash
sudo service tomcat7 stop
