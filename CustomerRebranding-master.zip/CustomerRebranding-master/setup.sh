#!/bin/bash
sudo yum install tomcat7 tomcat7-webapps -y
sudo rm -rf /usr/share/tomcat7/webapps/CustomerOnBoard-Raghib-0.0.1*
